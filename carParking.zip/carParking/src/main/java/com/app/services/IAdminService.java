package com.app.services;

import com.app.pojos.Admin;

public interface IAdminService {

	Admin authenticateAdmin(String email, String password);

	Admin registerAdmin(Admin a);

}
